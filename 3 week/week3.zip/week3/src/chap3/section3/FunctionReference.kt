package chap3.section3

fun main() {
    println(funcParam(3,2, ::sum1))

    val sum=::sum1
    sum(1,2)
    println(funcParam(3,2, sum))
    //람다식 매개변수가 없을 때
    noParam({ "hi" })
    noParam(){ "hihi" }
    noParam { "hihihi" }
    //람다식의 매개변수가 1개 일 때
    oneParam({a->"hello world! $a"})
    oneParam{a->"hello world! $a"}
    oneParam{"hello world! $it"}
    //람다식의 매개변수가 2개
    moreParam({a,b->"$a,$b"})
    withArgs("안녕", "친구들",{a,b->"$a 꼬마 $b"})
    twoLambda("안녕","친구들",{aa,bb->"$aa 꼬마 $bb"},{c->"$c 놀자"})
    twoLambda("안녕","친구들",{aa,bb->"$aa 꼬마 $bb"}){c->"$c 놀자"}

}

fun funcParam(a:Int, b:Int, c:(Int,Int)->Int):Int{
    return c(a,b)
}

fun sum1(a:Int,b:Int) =a+b

fun noParam(out:()->String)= println(out())

fun oneParam(out:(String)->String)= println(out("oneParam"))

fun moreParam(out:(String, String) ->String){
    println(out("oneParam", "two Param"))
}

fun withArgs(a: String, b: String, out: (String, String) -> String) {
    println(out(a, b))
}

fun twoLambda(a:String, b: String, out: (String, String) -> String){
    println(out(a,b))
}