package chap3.section3

fun main() {
    var result : Int        //변수에 할당하는 람다식
    var multi:(Int, Int)->Int = {x:Int, y:Int -> x*y}
    var multi2 = {x:Int , y: Int ->
        print("x * y = ")
        x * y       //람다식을 여러줄로 작성 할 때 마지막즐이 리턴이 된다
    }
    val multi3 = {x: Int, y: Int -> x * y}
    val multi4 : (Int, Int) -> Int = {x, y -> x * y}
    //  val multi5 = {x, y -> x * y}

    val greet:()->Unit = { println("\nHello") }
    greet()

    result = multi(10,20)
    println(result)
}

