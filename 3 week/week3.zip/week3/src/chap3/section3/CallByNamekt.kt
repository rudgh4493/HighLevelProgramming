package chap3.section3


fun main() {
    val result = callByName(otherlambda)
    println(result)

}


fun callByName(b:()->Boolean):Boolean{
    println("callByValue function")
    return b()
}


val otherlambda:() ->Boolean={
    println("otherlambda Function")
    true
}