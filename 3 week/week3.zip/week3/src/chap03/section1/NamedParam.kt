package chap03.section1

fun main(){
    println(namedParam(1,2,3))
    println(namedParam(z=500))
    println(namedParam(500))
    println(namedParam(z=500, a=3))

    normalVarargs(1,2,3,4,5,6,7,8,9)
    val numbers= intArrayOf(1,2,3,4,5)
    normalVarargs(*numbers)         //스프레드 연산자를 넣어서 배열을 넘길 수 있음

    println( highfunc({ x, y->x+y}, 100,200))
}

fun highfunc(s:(Int,Int)->Int, a:Int, b:Int):Int{
    return s(a,b)
}

fun namedParam(x:Int=100, y:Int=200, z:Int=1){
    println(x+y+z)
}

fun namedParam(x:Int=100, y:Int=200, z:Int=1, a:Int){
    println(x+y+z+a)
}

fun normalVarargs(vararg counts:Int){   //정수의 배열로 들어옴
    for(num in counts){
        print("$num")
    }
    println()
}