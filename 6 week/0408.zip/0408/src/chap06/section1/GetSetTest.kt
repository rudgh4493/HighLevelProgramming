package chap06.section1

//class User(val id:Int, var name:String, var age:Int)
class User(_id:Int, _name:String?, _age:Int){
    val id:Int = _id
    private var n :String?=_name
//        get() = field
  //  var name:String = _name
    var name: String?
        set(value){
            n= value ?:"NONAME"
//            println("이름 바꿈.")
//            field=value
        }get():String? = "$id : $n ($age)"
    val age:Int = _age
}

fun main(){
    val user =User (1,"asd",20)
    user.name="qwe"
    println("user${user.id} : ${user.name}(${user.age})")
}
//### [실습] 프로퍼티를 이용한 나이 속이기 예제
//
//나이를 받아들이는 setter를 구성해 인자가 18세 미만인 경우는 18세로 설정하고, 18세부터 30세 범위에 있는 경우에는 나이를 그대로 유지한다. 그 외 30세 초과인 경우에는 제시된 인자에서 3살을 빼고 설정하도록 구현한다.
//
//```kotlin
//
//```