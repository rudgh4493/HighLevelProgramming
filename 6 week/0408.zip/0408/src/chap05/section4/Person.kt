package chap05.section4

class Person(firstName: String, out: Unit = println("주생성자")){
//    constructor(firstName: String) {
//        println("[Person] firstName: $firstName")
//    }
    val fName = println("[Property] Person fName: $firstName") // ③ 프로퍼티 할당
    init {
        println("[init] Person 초기화 블록") // ④ 초기화 블록
    }
    constructor(firstName: String, age: Int, out: Unit = println("부생성자"))
            : this(firstName){
        println("[Secondary Constructor] Body: $firstName, $age") // ⑤ 부 생성자 본문
}
    fun main()
    {
//        val sean = Developer("Sean")
        val p1 = Person("kildong", 30)
    }
}
//class Developer: Person {
//    constructor(firstName: String): this(firstName, 10) { // ①
//        println("[Developer] $firstName")
//    }
//    constructor(firstName: String, age: Int): super(firstName, age) { // ②
//        println("[Developer] $firstName, $age")
//    }
//}