package chap05.section1

import org.intellij.lang.annotations.Language

open class Bird (var name:String, var wing:Int, var beak:String, var color:String) {

    fun fly() = println("Fly wing : $wing")
    open fun sing(vol:Int) = println("Sing val : $vol") //<<오버라이딩 하려면 open 써주기
}
//주 생성자를 사용하는 상속
class Lark(name: String, wing: Int, beak: String, color: String): Bird(name, wing, beak, color) {
    fun singHitone() = println("Happy Song!") // 새로 추가된 메서드
    override fun sing(vol: Int){ // <<오버라이딩 할거면 overide써주기
        println("$name is singing")

    }
}
//부 생성자를 사용하는 상속
class Parrot: Bird{
    val language: String
    constructor(name: String,wing: Int,beak: String,color: String, language: String)
            :super(name,wing,beak,color) {
            this.language = language
    }
    fun speak() = println("Speak! $language")
    override fun sing(vol: Int){ // <<오버라이딩 할거면 overide써주기
        super.sing(vol)
        speak()
    }
}
fun main() {
    val coco = Bird("mybird", 2, "short", "yellow")
    val lark = Lark("mylark", 2, "long", "brown")
    val parrot = Parrot("myparrot", 2, "short", "blue", "korean")

    println("coco : ${coco.name}, ${coco.color}")
    println("lark : ${lark.name}, ${lark.color}")
    println("parrot : ${parrot.name}, ${parrot.color}, ${parrot.language}")
//
//    coco.fly()
//    lark.singHitone()
//    parrot.speak()
    coco.sing(20)
    lark.sing(30)
    parrot.sing(50)
}