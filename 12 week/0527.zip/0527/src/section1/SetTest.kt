package section1

fun main() {
    // 가변형 List의 생성 및 추가, 삭제, 변경
    val mutableList: MutableList<String> = mutableListOf<String>("Kildong", "Dooly", "Chelsu")
    mutableList.add("Ben") // 추가
    mutableList.removeAt(1) // 인덱스 1 삭제
    mutableList[0] = "Sean" // 인덱스 0를 변경, set(index: Int, element: E)과 같은 역할
    println(mutableList)

    // 특정 자료형의 제네릭 표현을 쓰지 않으면 여러 자료를 혼합해 쓸 수 있는 가변형 리스트가 만들어짐
    val mutableListMixed = mutableListOf("Android", "Apple", 5, 6, 'X')
//__________________________
    val intsHashSet: HashSet<Int> = hashSetOf(6, 3, 4, 7) // 불변성 기능이 없음
    intsHashSet.add(5)  // 추가
    intsHashSet.remove(6)  // 삭제
    println(intsHashSet)


}