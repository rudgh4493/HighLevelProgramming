package section1

fun immutableListTest(){

    val fruits = listOf("apple", "banana", "kiwi")
// for와 in을 사용한 출력
    for (item in fruits) {
        println(item)
    }
    for (index in fruits.indices) { // 인덱스 지정
        println("fruits[$index] = ${fruits[index]}")
    }
    println(fruits)

    val emptyList: List<String> = emptyList<String>()
    val list1 = listOfNotNull(2, 45, 2, null, 5, null)
    println(list1)

    //_______________
    var names: List<String> = listOf("one", "two", "three")
    println(names.size) // List 크기
    println(names.get(0)) // 해당 인덱스의 요소 가져오기
    println(names.indexOf("three")) // 해당 요소의 인덱스 가져오기
    println(names.contains("two")) //  포함 여부 확인 후 포함되어 있으면 true 반환
}

fun main(){
    // 가변형 List를 생성하고 자바의 ArrayList로 반환
    val stringList: ArrayList<String> = arrayListOf<String>("Hello", "Kotlin", "Wow")
    stringList.add("Java") // 추가
    stringList.remove("Hello") // 삭제
    println(stringList)

    // 가변형 List의 생성 및 추가, 삭제, 변경
    val mutableList: MutableList<String> = mutableListOf<String>("Kildong", "Dooly", "Chelsu")
    mutableList.add("Ben") // 추가
    mutableList.removeAt(1) // 인덱스 1 삭제
    mutableList[0] = "Sean" // 인덱스 0를 변경, set(index: Int, element: E)과 같은 역할
    println(mutableList)
    // 특정 자료형의 제네릭 표현을 쓰지 않으면 여러 자료를 혼합해 쓸 수 있는 가변형 리스트가 만들어짐
    val mutableListMixed = mutableListOf("Android", "Apple", 5, 6, 'X')
}