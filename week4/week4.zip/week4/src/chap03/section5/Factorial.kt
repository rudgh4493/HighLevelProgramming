package chap03.section5

fun main(){
    val number = 3
    val result:Long
    println("Factorial : $number -> ${test.factorial(3)}")
    println("Factorial2 : $number -> ${test.factorial2(3)}")
}

fun factorial(n:Int):Long{
    if(n==1)
        return n.toLong()
    else
        return n* test.factorial(n - 1)
}

fun factorial2(n:Int, run:Int=1):Long{
    if(n==1)
        return run.toLong()
    else
        return test.factorial2(n - 1, run * n)
}

