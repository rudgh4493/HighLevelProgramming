package chap03.section5

import kotlin.contracts.Returns

fun main(){
    shortFunc(3){
        println("First call : $it")
        //return crossinline일 때 없애기
    }

    shortFunc(5){ println("Second call : $it") }

}

//inline fun shortFunc(a:Int, out:(Int)->Unit){
//    println("Before calling out()")
//    out(a)
//    println("After calling out()")
//
//}

inline fun shortFunc(a:Int, crossinline out:(Int)->Unit){
    println("Before calling out()")
    out(a)
    println("After calling out()")

}
inline fun inlineLambda(a:Int,b:Int,out: (Int,Int) -> Unit){

}

fun retFunc(){
    println("Start of retFunc")
    inlineLambda(13,3) {
            a,b->
        val result = a+b
        if(result>10) return @inlineLambda
        println("result: $result")
    }
    println("End of retFunc")
}
fun retFunc2(){
    println("Start of retFunc")
    inlineLambda(13,3, fun(a,b)) {
        val result = a+b
        if(result>10) return
        println("result: $result")
    }
    println("End of retFunc")
}


