package chap03.section5

fun main(){
    val source = "Hello World"
    val target = "Kotlin"
    println(source.getLongString(target))
    val num = 3
    println(num.multiply(4))
    println(num multiply(5))    //중위표현(infix notation)
}
//확장함수 만들기

//fun String.getLongString(target:String):String{
//    if(this.length>target.length)
//        return this
//    else
//        return target
//}

fun String.getLongString(target:String):String =
    if(this.length>target.length) this else target
//중위함수 만들기
infix fun Int.multiply(x:Int):Int{
    return this * x
}
