package chap03.section4
import java.util.concurrent.locks.Lock
import java.util.concurrent.locks.ReentrantLock


var sharable = 1
val add1:(Int, Int) -> Int= {x:Int,y:Int -> x+y}
val add2 = fun (x:Int, y:Int):Int{
    return x+y
}
val add3 = fun (x:Int, y:Int):Int=x+y

fun

fun main(){
    add1(1,2)
    add2(3,4)

    var reLock = ReentrantLock()
    lock(reLock, ::criticalFunc)
    println(sharable)
    lock(reLock, { criticalFunc() })
    println(sharable)
    lock(reLock){ criticalFunc() }
    println(sharable)
}

fun criticalFunc(){
    sharable += 1
}

fun <T> lock(reLock: ReentrantLock, body:()->T):T{
    reLock.lock()
    try{
        return body()
    }finally {
        reLock.unlock()
    }
}