package chap10.section1

fun main() {
    var m = 1
    m = m.also { it + 3 }
    println(m) // 원본 값 1

    val firstName: String? ="ASDF"
    var lastName: String = "QWER"
    // if 문을 사용한 경우
    if (null != firstName) {
        println("$firstName $lastName")
    } else {
        println("$lastName")
    }
    // let을 사용한 경우
    firstName?.let { println("$it $lastName") } ?: println("$lastName")

    val score: Int? = 32 //32
    //var score = null

    // 일반적인 null 검사
    fun checkScore() {
        if (score != null) {
            println("Score: $score")
        }
    }

    // let을 사용해 null 검사를 제거
    fun checkScoreLet() {
        score?.let {
            println("Score: $it")
        } // ①
        val str = score.let {
            it.toString()
        } // ②
        println(str)
    }

    checkScore()
    checkScoreLet()
}