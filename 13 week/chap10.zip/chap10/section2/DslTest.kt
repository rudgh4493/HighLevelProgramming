package chap10.section2

import jdk.jfr.Category

data class Person(var name:String ?= null,
                  var age:Int? = null,
                  var job:Job? =null)
data class Job(var category:String ?= null,
               var position:String? = null,
               var extension:Int? =null)


//람다식을 매개변수로 가지고 Person객체를 반환하는 person 함수 정의
fun person(block:(Person)->Unit):Person{
    val p = Person()
    block(p)
    return p
}

val person = person {
    it.name = "Kildong"
    it.age = 40
}
fun Person.job(block:Job.()->Unit){
    job = Job().apply(block)
}