package section1

// 무변성(Invariance) 선언
//class Box1<T>(val size: Int)

class Box1<in T>(val size: Int)

open class Animal(val size: Int) {
    fun feed() = println("Feeding...")
}

class Cat(val jump: Int): Animal(50)

class Spider(val poison: Boolean): Animal(1)

// ① 형식 매개변수를 Animal로 제한
class ABox<out T: Animal>(val element: T) { // out을 사용하는 경우 주 생성자에서 val만 허용
    fun getAnimal(): T = element // ② out은 반환 자료형에만 사용할 수 있음
//    fun set(new: T) { // ③ 오류! T는 in 위치에 사용할 수 없음
//        element = new
//    }
}

fun main() {
    val c1: Cat = Cat(10)
    val s1: Spider = Spider(true)

    // 클래스의 상위 자료형 변환은 아무런 문제 없음
    var a1: Animal = c1
    a1 = s1 //  ④ a1은 Spider의 객체가 됨
    println("a1.size = ${a1.size}")
    // ⑤ 공변성- Cat은 Animal의 하위 자료형
    val c2: ABox<Animal> = ABox<Cat>(Cat(10))
    println("c2.element.size = ${c2.element.size}")
    // ⑥ 반대의 경우는 가능하지 않음
//    val c3: Box<Cat> = Box<Animal>(10) // 오류!
    // ⑦ 자료형이 제한하여 Animal과 하위 클래스 이외에는 사용할 수 없음
//    val c4: Box<Any> = Box<Int>(10) // 오류!







    //Int가 Any의 하위 타입이라고 해서
    //Box<Int>가 Box<Any>의 하위 타입이 되는 것은 아니다.
    //val anys:Box1<Any> = Box1<Int>(10)    //자료형 불일치 오류.
    //val nothings: Box<Nothing> = Box1<Int>(20)//자료형 불일치 오류.
    val nothings: Box1<Nothing> = Box1<Int>(20)//자료형 불일치 오류.
}