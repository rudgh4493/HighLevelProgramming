package chap04.section1

fun main(){
//    print("점수입력: ")
//    val score = readLine()!!.toDouble()
//    var grade: Char = 'F'
//
//    when(score){
//        in 90.0..100.0 -> grade = 'A'
//        in 80.0..89.9 -> grade = 'B'
//        in 70.0..79.9 -> grade = 'C'
//        !in 70.0..100.0 -> grade = 'F'
//        else ->grade = 'F'
//    }
//    println("Score : $score, Grade:$grade")


    cases("Hello") // ② String
    cases(1) // Int
    cases(System.currentTimeMillis()) // Long
    cases(MyClass()) // 객체
}

class MyClass

fun cases(obj: Any) {
    when (obj) {
        1 -> println("Int: $obj")
        "Hello" -> println("String: $obj")
        is Long -> println("Long: $obj")
        !is String -> println("Not a String")
        else -> println("Unknown")
    }
}