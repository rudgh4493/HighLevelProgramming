package chap04.section2

fun main(){
    print("줄 수: ")
    val n= readLine()!!.toInt()
    for (x in 1..n) {
        for (space in 1..(n-x)) { print(' ') }
        for (star in 1..(2*x-1)) {print('*') }
        println()
    }




//    for (i in 1..4){
//        print(" ")
//        for (ii in 1..4){
//            print("*")
//
//        }
//
//    }

}