package chap04.section2

fun main(){
    var total : Int = 0
    for(n in 2..100 step 2) total += n
    println("짝수의 합: $total")
}

