package chap5.section1

...
class Bird (var name: String, var wing: Int, var beak: String, var color: String) {
    init {
        println("초기화 블록")
        println("이름은 $name, 부리는 $beak")
        this.sing(3)
        println("초기화 블록 끝")
    }
//    // property
//    var name: String
//    var wing: Int
//    var beak: String
//    var color: String

//        var name: String = _name
//        var wing: Int = _wing
//        var beak: String = _beak
//        var color: String = _color

    // method
    fun fly() = println("Fly wing: $wing")
    fun sing(vol: Int) = println("Sing vol: $vol")
}

fun main() {
    val coco = Bird()
    coco.color = "blue"

    println("coco.color: ${coco.color}")
    coco.fly()
    coco.sing(3)
}