package chap02.section1

import Person
import kotlin.math.*
/*import kotlin.math.PI
import kotlin.math.abs*/

fun main(){
    val user1 = Person("Gildong", 30)
    println(user1)

    val intro:String = "안녕하세요"
    val num:Int = 20

    println(PI)
    println(abs(-12.6))


    println("Intro : $intro, num : $num")
}

class Person(val name:String, val age:Int, val addr:String)