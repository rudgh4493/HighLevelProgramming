package chap02.section2

fun checkArg(x:Any){
    if (x is String)
        println("x is String : $x")
    if (x is Int)
        println("x is Int : $x")
}

fun main(){
    val num1 = 12
    val num2 = 25
    val result : Int
    result = num1 or num2
    println(result)





    checkArg("Hello")
    checkArg(15)

    val x:Any
    x = "Hello"

    if(x is String){
        print(x.length)
    }




    var str1:String? = "Hello Kotlin"
    str1 = null

    println("str1 : $str1 \t legnth : ${str1?.length}")
}

