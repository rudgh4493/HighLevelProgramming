package section3

data class Vector(val x: Double, val y: Double) {
    // plus 함수의 연산자 오버로딩
    operator fun plus(v: Vector) : Vector {
        return Vector(x + v.x, y + v.y)
    }

    operator fun times(scalar: Double): Vector {
        return Vector(x * scalar, y * scalar)
    }

    operator fun times(v: Vector): Vector {
        return Vector(x * v.x, y * v.y)
    }
}

fun main() {
    val v1 = Vector(2.0, 3.0)
    val v2 = Vector(5.0, 7.5)

    val v3 = v1 + v2
    println("v1 + v2 = $v3")

    val v4 = v1 * v2
    println("v1 * v2 = $v4")
}