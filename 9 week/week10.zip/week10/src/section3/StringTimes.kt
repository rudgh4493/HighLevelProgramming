package section3

operator fun String.times(n: Int): String {
    if (n <= 0) throw IllegalArgumentException("반복 횟수는 1 이상이어야 합니다.")

    var result = ""
    for (i in 1..n) {
        result += this
    }
    return result
}

fun main() {
    try {
        val stringTime1 = "Hi" * 3
        println(stringTime1)

        val stringTime2 = "Hello" * 2
        println(stringTime2)

        val stringTime3 = "Hello" * 0
        println(stringTime3)

    } catch (e: IllegalArgumentException) {
        println(e.message)
    }
}
