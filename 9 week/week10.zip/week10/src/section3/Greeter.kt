package section3

class Greeter(val greeting: String) {

    // invoke 연산자 오버로딩
    operator fun invoke(name: String) {
        println("$greeting, $name!")
    }
}

fun main() {
    val hello = Greeter("Hello")
    val annyong = Greeter("안녕하세요")

    hello("World")
    annyong("세계")
}
