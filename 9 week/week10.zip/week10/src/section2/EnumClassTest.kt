package section2

enum class Direction {
    NORTH, SOUTH, WEST, EAST
}

enum class DayOfWeek(val num: Int) {
    MONDAY(1), TUESDAY(2), WEDNESDAY(3), THURSDAY(4),
    FRIDAY(5), SATURDAY(6), SUNDAY(7)
}


enum class Color(val r: Int, val g: Int, val b: Int) {
    RED(255, 0, 0), ORANGE(255, 165, 0),
    YELLOW(255, 255, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
    INDIGO(75, 0, 130), VIOLET(238, 130, 238);  // 여기에 세미콜론으로 끝을 알리고

    fun rgb() = (r * 256 + g) * 256 + b // 메서드를 포함할 수 있음
}

interface Score {
    fun getScore(): Int
}

enum class MemberType(var prio: String) : Score { // Score를 구현할 열거형 클래스
    NORMAL("Thrid") {
        override fun getScore(): Int  = 100  // 구현된 메서드
    },
    SILVER("Second") {
        override fun getScore(): Int  = 500
    },
    GOLD("First") {
        override fun getScore(): Int  = 1500
    }
}

fun main(){
    println(MemberType.NORMAL.getScore())
    println(MemberType.GOLD)
    println(MemberType.valueOf("SILVER"))
    println(MemberType.SILVER.prio)
    for (grade in MemberType.values()) {  // 모든 값을 가져오기 위한 반복문
        println("grade.name = ${grade.name}, prio = ${grade.prio}")
    }


    println(Color.BLUE.rgb())


    val day = DayOfWeek.SATURDAY // SATURDAY의 값을 읽기
    when(day.num) {
        1, 2, 3, 4, 5 -> println("Weekday")
        6, 7 -> println("Weekend!")
    }
}