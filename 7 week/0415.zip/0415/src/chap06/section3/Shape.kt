package section3

interface Shape{
    fun onDraw()
}
fun foo(a:Int, b:Int){
    val adHoc = object{
        var x: Int = a
        var y: Int = b
    }
    println(adHoc.x + adHoc.y)
}
fun main() {
    val triangle = object: Shape{
        override fun onDraw() {
            println("삼각형을 그려요~")
        }
    }
    triangle.onDraw()
}