package chap06.section3

fun main() {
    println(Customer.LEVEL)
    Customer.login()
}