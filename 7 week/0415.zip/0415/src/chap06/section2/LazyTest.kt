package chap06.section2

class LazyTest{

    init {
        println("초기화 블록")
    }
    val subject by lazy{
        println("lazy를 사용한 프로퍼티 지연 초기화")
        "Kotlin Programming"
    }
    fun flow(){
        println("not initialized") //  ④
        println("subject one: $subject") // ⑤ 최초 초기화 시점!
        println("subject two: $subject") // ⑧ 이미 초기화된 값 사용
    }


}
fun main() {
    val test = LazyTest() // ①
    test.flow() // ③
}