//package chap06.section2
//
//data class Person(var name:String, var age:Int)
//lateinit var person1: Person // 객체 생성의 지연 초기화
//
//class Person{
//    lateinit var name:String
//    fun test(){
//        if(!::name.isInitialized){
//            println("not initialized")
//        }
//        else{
//            println("initialized")
//        }
//    }
//}
//fun main() {
//    person1 = Person("Kildong",30)
//    print(person1.name + " is " + person1.age.toString())
//
//
//    val kildong = Person()
//    kildong.test()
//    kildong.name = "Kildong" // ③ 이 시점에서 초기화됨(지연 초기화)
//    kildong.test()
//    println("name = ${kildong.name}")
//}